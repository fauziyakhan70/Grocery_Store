﻿using GroceryHX.Data;
using GroceryHX.Data.Services;
using GroceryHX.Data.Static;
using GroceryHX.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace GroceryHX.Controllers
{
    [Authorize(Roles = UserRoles.Admin)]
    public class ProductsController : Controller
    {

        private readonly IProductsService _service;
        public ProductsController(IProductsService service)
        {
            _service = service;
        }
        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            var allProducts = await _service.GetAllAsync(n => n.Supplier);
            return View(allProducts);
        }
        [AllowAnonymous]
        public async Task<IActionResult> Filter(string searchString)
		{
			var allProducts = await _service.GetAllAsync(n => n.Supplier);
            if (!string.IsNullOrEmpty(searchString))
            {
                var filteredResult = allProducts.Where(n => n.Name.Contains(searchString) || n.Description.Contains(searchString)).ToList();
                return View("Index", filteredResult);
            }
			return View("Index", allProducts);
		}
        [AllowAnonymous]
        //Details
        public async Task<IActionResult> Details(int id)
        {
            var productDetail = await _service.GetProductByIdAsync(id);
            return View(productDetail);
        }

        //Create
        public async Task<IActionResult> Create()
        {
            var productDropdownsData = await _service.GetNewProductDropdownsValues();
            ViewBag.Suppliers = new SelectList(productDropdownsData.Suppliers, "Id", "Name");
			ViewBag.Producers = new SelectList(productDropdownsData.Producers, "Id", "Name");
			ViewBag.Countries = new SelectList(productDropdownsData.Countries, "Id", "Name");
			return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(NewProductVM product)
        {
            if(!ModelState.IsValid)
            {
                var productDropdownsData = await _service.GetNewProductDropdownsValues();
                ViewBag.Suppliers = new SelectList(productDropdownsData.Suppliers, "Id", "Name");
                ViewBag.Producers = new SelectList(productDropdownsData.Producers, "Id", "Name");
                ViewBag.Countries = new SelectList(productDropdownsData.Countries, "Id", "Name");
                return View(product);
            }
            await _service.AddNewProductAsync(product);
            return RedirectToAction(nameof(Index));
        }


        public async Task<IActionResult> Edit(int id)
        {
            var productDetails = await _service.GetProductByIdAsync(id);
            if(productDetails == null) return View("NotFound");

            var response = new NewProductVM()
            {
                Id = productDetails.Id,
                Name = productDetails.Name,
                Description = productDetails.Description,
                Price = productDetails.Price,
                ExpiryDate = productDetails.ExpiryDate,
                ImageURL = productDetails.ImageURL,
                ProductCatogary = productDetails.ProductCatogary,
                SupplierId = productDetails.SupplierId,
                ProducerId = productDetails.ProducerId,
                CountryIds = productDetails.Country_Products.Select(n => n.CountryId).ToList(),
            };


            var productDropdownsData = await _service.GetNewProductDropdownsValues();
            ViewBag.Suppliers = new SelectList(productDropdownsData.Suppliers, "Id", "Name");
            ViewBag.Producers = new SelectList(productDropdownsData.Producers, "Id", "Name");
            ViewBag.Countries = new SelectList(productDropdownsData.Countries, "Id", "Name");
            return View(response);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, NewProductVM product)
        {
            if (id != product.Id) return View("NotFound");

            if (!ModelState.IsValid)
            {
                var productDropdownsData = await _service.GetNewProductDropdownsValues();
                ViewBag.Suppliers = new SelectList(productDropdownsData.Suppliers, "Id", "Name");
                ViewBag.Producers = new SelectList(productDropdownsData.Producers, "Id", "Name");
                ViewBag.Countries = new SelectList(productDropdownsData.Countries, "Id", "Name");
                return View(product);
            }
            await _service.UpdateProductAsync(product);
            return RedirectToAction(nameof(Index));
        }
    }
}
