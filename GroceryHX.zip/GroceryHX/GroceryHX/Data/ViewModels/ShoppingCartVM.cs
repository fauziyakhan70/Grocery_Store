﻿using GroceryHX.Data.Cart;

namespace GroceryHX.Data.ViewModels
{
	public class ShoppingCartVM
	{
		public ShoppingCart ShoppingCart { get; set; }
		public double ShoppingCartTotal { get; set; }
	}
}
