﻿using GroceryHX.Data.Base;
using GroceryHX.Models;

namespace GroceryHX.Data.Services
{
    public interface IProducersService : IEntityBaseRepository<Producer>
    {
    }
}
