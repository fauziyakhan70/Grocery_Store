﻿namespace GroceryHX.Data.Enums
{
    public enum ProductCatogary
    {
        Fruit = 1,
        Vegetable,
        Pulse,
        DairyProduct
    }
}
